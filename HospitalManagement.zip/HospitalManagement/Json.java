import java.util.List;
import java.util.Locale;

/**
 * Tiny JSON writer so the project needs no external libraries.
 * Usage: Json.object().put("name", "Ravi").put("age", 45).build()
 */
public final class Json {
    private final StringBuilder sb = new StringBuilder("{");
    private boolean first = true;

    public static Json object() {
        return new Json();
    }

    private Json key(String key) {
        if (!first) {
            sb.append(',');
        }
        first = false;
        sb.append(quote(key)).append(':');
        return this;
    }

    public Json put(String key, String value) {
        key(key);
        sb.append(value == null ? "null" : quote(value));
        return this;
    }

    public Json put(String key, long value) {
        key(key);
        sb.append(value);
        return this;
    }

    public Json put(String key, double value) {
        key(key);
        sb.append(String.format(Locale.ROOT, "%.2f", value));
        return this;
    }

    public Json put(String key, boolean value) {
        key(key);
        sb.append(value);
        return this;
    }

    /** Adds a value that is already valid JSON (an object or an array). */
    public Json putRaw(String key, String rawJson) {
        key(key);
        sb.append(rawJson);
        return this;
    }

    public String build() {
        return sb + "}";
    }

    public static String array(List<Json> items) {
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                out.append(',');
            }
            out.append(items.get(i).build());
        }
        return out.append(']').toString();
    }

    public static String stringArray(List<String> items) {
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                out.append(',');
            }
            out.append(quote(items.get(i)));
        }
        return out.append(']').toString();
    }

    public static String quote(String s) {
        StringBuilder out = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        return out.append('"').toString();
    }
}
