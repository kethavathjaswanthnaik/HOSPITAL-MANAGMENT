/**
 * Base class for everyone the hospital keeps a record of.
 * Patient and Doctor extend it (inheritance) and each reports its own role (polymorphism).
 */
public abstract class Person {
    private final int id;
    private final String name;
    private final int age;
    private final String phone;

    protected Person(int id, String name, int age, String phone) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.phone = phone;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getPhone() { return phone; }

    /** "Patient" or "Doctor" */
    public abstract String getRole();

    public Json toJson() {
        return Json.object()
                .put("id", id)
                .put("name", name)
                .put("age", age)
                .put("phone", phone)
                .put("role", getRole());
    }
}
