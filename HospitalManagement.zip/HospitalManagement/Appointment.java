import java.time.LocalDate;

/** One booked time slot between a patient and a doctor. */
public class Appointment {

    public enum Status { BOOKED, COMPLETED, CANCELLED }

    private final int id;
    private final int patientId;
    private final int doctorId;
    private final LocalDate date;
    private final String time;
    private Status status = Status.BOOKED;
    private boolean billed;

    public Appointment(int id, int patientId, int doctorId, LocalDate date, String time) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
    }

    public int getId() { return id; }
    public int getPatientId() { return patientId; }
    public int getDoctorId() { return doctorId; }
    public LocalDate getDate() { return date; }
    public String getTime() { return time; }
    public Status getStatus() { return status; }
    public boolean isBilled() { return billed; }

    /** A cancelled appointment frees its slot; every other status keeps it taken. */
    public boolean holdsSlot() {
        return status != Status.CANCELLED;
    }

    public void complete() {
        requireBooked("completed");
        status = Status.COMPLETED;
    }

    public void cancel() {
        requireBooked("cancelled");
        status = Status.CANCELLED;
    }

    public void markBilled() {
        billed = true;
    }

    private void requireBooked(String verb) {
        if (status != Status.BOOKED) {
            throw new HospitalException("Only a booked appointment can be " + verb
                    + ". This one is already " + status.name().toLowerCase() + ".");
        }
    }

    public Json toJson() {
        return Json.object()
                .put("id", id)
                .put("patientId", patientId)
                .put("doctorId", doctorId)
                .put("date", date.toString())
                .put("time", time)
                .put("status", status.name())
                .put("billed", billed);
    }
}
