import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** A registered patient. A patient is either an outpatient or admitted to a ward. */
public class Patient extends Person {
    private final String gender;
    private final String condition;
    private boolean admitted;
    private LocalDate admitDate;

    public Patient(int id, String name, int age, String gender, String phone, String condition) {
        super(id, name, age, phone);
        this.gender = gender;
        this.condition = condition;
    }

    public String getGender() { return gender; }
    public String getCondition() { return condition; }
    public boolean isAdmitted() { return admitted; }
    public LocalDate getAdmitDate() { return admitDate; }

    @Override
    public String getRole() {
        return "Patient";
    }

    public void admit(LocalDate date) {
        if (admitted) {
            throw new HospitalException(getName() + " is already admitted.");
        }
        admitted = true;
        admitDate = date;
    }

    public void discharge() {
        admitted = false;
        admitDate = null;
    }

    /** Ward days to charge: calendar days since admission, with a minimum of one day. */
    public int wardDays(LocalDate today) {
        if (!admitted) {
            return 0;
        }
        return (int) Math.max(1, ChronoUnit.DAYS.between(admitDate, today));
    }

    @Override
    public Json toJson() {
        return super.toJson()
                .put("gender", gender)
                .put("condition", condition)
                .put("admitted", admitted)
                .put("admitDate", admitDate == null ? null : admitDate.toString());
    }
}
