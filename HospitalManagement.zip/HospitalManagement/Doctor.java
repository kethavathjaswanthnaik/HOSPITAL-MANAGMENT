/** A doctor with a specialisation and a fixed consultation fee. */
public class Doctor extends Person {
    private final String specialization;
    private final double consultationFee;

    public Doctor(int id, String name, int age, String phone, String specialization, double consultationFee) {
        super(id, name, age, phone);
        this.specialization = specialization;
        this.consultationFee = consultationFee;
    }

    public String getSpecialization() { return specialization; }
    public double getConsultationFee() { return consultationFee; }

    @Override
    public String getRole() {
        return "Doctor";
    }

    @Override
    public Json toJson() {
        return super.toJson()
                .put("specialization", specialization)
                .put("fee", consultationFee);
    }
}
