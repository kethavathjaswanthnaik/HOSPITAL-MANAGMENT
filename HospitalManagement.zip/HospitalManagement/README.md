# Lifeline Hospital - Hospital Management System

A hospital front-desk application built with a **Java backend** (`com.sun.net.httpserver.HttpServer`)
and an **HTML / CSS / JavaScript** front end. No Tomcat, Spring, database or external libraries needed.
Modelled on the Mafia Bank project: the browser talks to a small Java server over HTTP, and all data
lives in memory.

## Run it

Requires Java 17 or newer (developed and tested on Java 21).

```
cd HospitalManagement
javac *.java
java HospitalServer
```

Then open **http://localhost:7070** in a browser. Stop the server with `Ctrl + C`.
Run `java HospitalServer` from inside the project folder, because the server reads `index.html` and `style.css` from the current directory.

## Files

| File | Purpose |
|---|---|
| `Person.java` | Abstract base class: id, name, age, phone |
| `Patient.java` | Extends Person: gender, reason for visit, admit / discharge, ward days |
| `Doctor.java` | Extends Person: specialization, consultation fee |
| `Appointment.java` | Booked / completed / cancelled time slot between a patient and a doctor |
| `Bill.java` | Receipt: consultation charges + ward charges |
| `Hospital.java` | In-memory data and all business rules |
| `HospitalException.java` | Custom exception for rule violations (shown to the user as a message) |
| `Json.java` | Small JSON writer (no libraries) |
| `HospitalServer.java` | HTTP server on port 7070: serves the site and handles `/api/...` requests |
| `index.html` | Web interface and JavaScript |
| `style.css` | Page styling |

## Features

- **Schedule**: a day board with one row per doctor and one column per hour; click a free slot to book it.
- **Patients**: register patients, admit them to a ward, generate a bill, discharge.
- **Doctors**: list with specialization, fee and today's load.
- **Bills**: every bill issued, with a printable receipt.

## Rules enforced by the Java code

- Name: letters only. Age: whole number 0 to 120. Phone: exactly 10 digits. Gender and reason are required.
- Appointments: hourly slots 09:00 to 17:00 (13:00 is lunch); no past dates; a doctor cannot be double-booked;
  a patient cannot hold two appointments at the same time; a cancelled slot becomes free again.
- Only a booked appointment can be completed or cancelled; a future appointment cannot be completed yet.
- Billing = completed, unbilled consultations (doctor's fee) + ward stay (Rs 1,500 per day, minimum 1 day).
  Billing an admitted patient also discharges them. A patient with nothing to bill is rejected.

## HTTP API

| Method and path | Fields | Result |
|---|---|---|
| `GET /api/dashboard` | | counts, revenue, slot list |
| `GET /api/patients` `/doctors` `/appointments` `/bills` | | JSON lists |
| `POST /api/patients` | name, age, gender, phone, condition | registers a patient |
| `POST /api/appointments` | patientId, doctorId, date (YYYY-MM-DD), time | books a slot |
| `POST /api/appointments/status` | id, action (`complete` or `cancel`) | updates an appointment |
| `POST /api/admit` | patientId | admits to ward |
| `POST /api/bill` | patientId | generates a bill (and discharges) |

Errors come back as `{"error": "..."}` with status 400.

## Limitation

Data is stored in memory, so the sample data (5 doctors, 3 patients, 3 appointments) is reloaded and
all changes are lost whenever the server restarts. Future work: permanent storage (JDBC / SQLite),
staff login, patient history, and stronger security.
