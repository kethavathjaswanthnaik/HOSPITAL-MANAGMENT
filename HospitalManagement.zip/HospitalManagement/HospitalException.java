/**
 * Thrown when a request breaks a hospital rule (bad input, double booking, etc.).
 * The server turns the message into an error response that the web page displays.
 */
public class HospitalException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public HospitalException(String message) {
        super(message);
    }
}
