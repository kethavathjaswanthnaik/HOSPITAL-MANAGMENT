import java.time.LocalDate;

/** A receipt produced when a patient is billed. */
public class Bill {
    private final int id;
    private final int patientId;
    private final String patientName;
    private final LocalDate date;
    private final int consultations;
    private final double consultationCharges;
    private final int wardDays;
    private final double wardCharges;

    public Bill(int id, int patientId, String patientName, LocalDate date,
                int consultations, double consultationCharges, int wardDays, double wardCharges) {
        this.id = id;
        this.patientId = patientId;
        this.patientName = patientName;
        this.date = date;
        this.consultations = consultations;
        this.consultationCharges = consultationCharges;
        this.wardDays = wardDays;
        this.wardCharges = wardCharges;
    }

    public int getId() { return id; }
    public String getPatientName() { return patientName; }
    public int getWardDays() { return wardDays; }

    public double getTotal() {
        return consultationCharges + wardCharges;
    }

    public Json toJson() {
        return Json.object()
                .put("id", id)
                .put("patientId", patientId)
                .put("patientName", patientName)
                .put("date", date.toString())
                .put("consultations", consultations)
                .put("consultationCharges", consultationCharges)
                .put("wardDays", wardDays)
                .put("wardCharges", wardCharges)
                .put("total", getTotal());
    }
}
